from phidias.Lib import *
from front_end_mas import *

# run the engine shell
PHIDIAS.shell(globals())

